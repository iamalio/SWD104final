
const express = require('express');
const app = express();
const handlebars = require('express-handlebars');
const sqlite3 = require("sqlite3").verbose();
const Sequelize = require("Sequelize");
const passport = require("passport");
const passportLocal = require("passport-local");
var bodyParser = require('body-parser');
   app.use(bodyParser.json()); // support json encoded bodies
   app.use(bodyParser.urlencoded({ extended: true })); // support encoded bodies
const Op = Sequelize.Op;
var db = new sqlite3.Database("./swd105DB.sqlite");
const sequelize = new Sequelize("swd105DB", "Peter", null, {
    operatorsAliases: false,
    host: "localhost",
    dialect: "sqlite",
    storage: "./swd105DB.sqlite"
  });
 

db.run('CREATE TABLE if not exists users(id, username, password, salt)');
db.run('CREATE TABLE if not exists newPost(name, newpost)');
  
app.post('/newPost', (req, res) => {
newPost.findOrCreate({
where: {
        name: req.body.name,
        newpost: req.body.newpost
        }
    });
});
app.post('/users', (req, res) => {
users.findOrCreate({
where: {
    id: (''),
        username: req.body.username,
        password: req.body.password,
        salt: ('salt')
        }
    });
});

 

  var crypto = require('crypto');
  

  function hashPassword(password, salt) {
    var hash = crypto.createHash('sha256');
    hash.update(password);
    hash.update(salt);
    return hash.digest('hex');
  }
  
  passport.use(new passportLocal(function(username, password, done) {
    db.get('SELECT salt FROM users WHERE username = ?', username, function(err, row) {
      if (!row) return done(null, false);
      var hash = hashPassword(password, row.salt);
      db.get('SELECT username, id FROM users WHERE username = ? AND password = ?', username, hash, function(err, row) {
        if (!row) return done(null, false);
        return done(null, row);
      });
    });
  }));

  passport.serializeUser(function(user, done) {
    return done(null, user.id);
  });
  
  passport.deserializeUser(function(id, done) {
    db.get('SELECT id, username FROM users WHERE id = ?', id, function(err, row) {
      if (!row) return done(null, false);
      return done(null, row);
    });
  });
  
  // ...
  
  app.post('/login', passport.authenticate('local', { successRedirect: './User',
                                                      failureRedirect: './newUser' }));



app.engine('handlebars', handlebars({ defaultLayout: 'main'}));
app.set('view engine', 'handlebars');

app.get('/newPost', (request, response) => {
    response.render('./newPost');
});
app.get('/logout', (request, response) => {
    response.render('./logout');
});
app.get('/newUser', (request, response) => {
    response.render('./newUser');
});

app.set("port", process.env.PORT || 3000);
app.listen(3000, () => {
    console.log('IMposter started on port 3000, press Ctrl+C to terminate.' );
  });

